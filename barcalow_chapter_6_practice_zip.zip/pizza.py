# Let's make a pizza py!
pizza = {
    "crust": "thick",  # Get that lame thin crust out of here.
    "toppings": ["pepperoni", "mushrooms", "black olives", "green peppers",
                 "sausage", "onions"]
}

print(f"You asked for a pizza with a {pizza.get("crust", "thick")} crust and "
      f"the following toppings:")
for topping in pizza.get("toppings", ["cheese"]):
    print(f"- {topping}")