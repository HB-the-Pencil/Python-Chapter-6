# Make a dictionary of users, with a dictionary about said users.
users = {
    "a_einstein": {
        "first": "albert",
        "last": "einstein",
        "location": "princeton"
    },
    "m_curie": {
        "first": "marie",
        "last": "curie",
        "location": "paris"
    },
    "g_mendel": {
        "first": "gregor",
        "last": "mendel",
        # Note the omitted location (because I don't know it).
    },
    "l_da_vinci": {
        "first": "leonardo",
        "location": "vinci"
    }
}

# Print information about the users.
for username, data in users.items():
    print(f"Username: {username}")

    # Catch errors in case the name is incomplete.
    full_name = f"{data.get("first", "error")} {data.get("last", "error")}"
    if full_name.__contains__("error"):
        full_name = "unknown"

    # Catch errors in the location.
    location = data.get("location", "unknown")

    # Print out the user's information.
    print(f"  Real Name: {full_name.title()}")
    print(f"  Location: {location.title()}")