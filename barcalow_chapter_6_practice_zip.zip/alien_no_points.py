# Another alien dictionary.
alien_0 = {"color": "green", "speed": "slow"}

# This is interesting....
print(alien_0.get("points", "There aren't points for this alien."))