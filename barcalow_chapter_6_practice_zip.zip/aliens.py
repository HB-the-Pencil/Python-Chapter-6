# Define three dictionaries of aliens.
alien_0 = {"color": "green", "points": 5}
alien_1 = {"color": "yellow", "points": 10}
alien_2 = {"color": "red", "points": 15}

# I hope we get to actually make a game with this at some point.
aliens = [alien_0, alien_1, alien_2]

for alien in aliens:
    print(alien)

# Oh! Hey! There is a better way to do this!
aliens = []

for alien in range(30):
    new_alien = {"color": "green", "points": 5, "speed": "slow"}
    aliens.append(new_alien)

# We can even change the properties of some of them.
for alien in aliens[:3]:
    if alien["color"] == "green":
        alien["color"] = "yellow"
        alien["points"] = 10
        alien["speed"] = "medium"

for alien in aliens[:5]:  # This is a cool way to print the first 5 aliens.
    print(alien)
print(f"That was 5 out of {len(aliens)} aliens.")