# Users and their favorite programming languages.
favorite_languages = {
    "ian": "c++",
    "brian": "c#",
    "adam": "basic",
    "charlie": "rust",
}

name = input("Input a user to get their favorite programming language: ")

print(f"{name.title()}'s favorite language is "
      f"{favorite_languages.get(name, "undefined").title()}.")

# Coming back from the future, here is a way to loop through the whole list:
for name, language in favorite_languages.items():
    print(f"{name.title()}'s favorite language is {language.title()}.")

# Who responded to the survey? We can just look at the keys.
friends = ['tom', 'ian']

for name in favorite_languages.keys():
    print(f"{name.title()} took the survey")
    if name in friends:
        print(f"\tHmmm... I know {name.title()}.")

# The .keys() method may be omitted. This is actually how I taught myself
# to loop through lists.

# This does not check the values for "ethan", only the keys.
if "ethan" not in favorite_languages:
    print("ETHAN TAKE THE SURVEY")

# Other things to remember:
#   sorted() works on key lists
#   the .values() method returns a list of the values
#   .values() does not check for repeats (but set(dict.values()) does)
#   sets can be defined with curly braces (otherwise like a list or tuple)
#   sets DO NOT retain the order that items were added

# Back from the future again to add lists in dictionaries.
favorite_languages = {
    "ian": ["c++", "c", "c#"],
    "brian": ["swift", "kotlin"],
    "adam": ["basic"],
    "charlie": ["html", "css", "js"]
}

# Print everybody's name and favorite languages.
for name, languages in favorite_languages.items():
    # Quick little grammar check.
    print(f"{name.title()}'s favorite language{" is" if len(languages) == 1
                                               else "s are"}", end=" ")
    # We can use for loops for lists inside for loops for dictionaries.
    for language in languages:
        # More basic grammar checking.
        print(language.title(),
              end=", " if languages.index(language) < len(languages) - 1
              else ".\n")