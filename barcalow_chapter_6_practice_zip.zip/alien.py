# Create a dictionary of an alien. Wow, that was easy.
alien_0 = {"color": "green", "points": 5}

print(alien_0)

# Set two new keys in the dictionary.
alien_0["x_pos"] = 25
alien_0["y_pos"] = 50

# Change the color.
print(f"Alien 0 is {alien_0["color"]}.")
alien_0["color"] = "yellow"
print(f"Now alien 0 is {alien_0["color"]}.")

# Change the speed.
alien_0["speed"] = "medium"
print(f"Alien 0 is at X {alien_0["x_pos"]}.")

# Why not just set speed to the increment variable? Then you can also change
# one alien's speed without changing the others.
if alien_0["speed"] == "slow":
    x_increment = 1
elif alien_0["speed"] == "medium":
    x_increment = 2
elif alien_0["speed"] == "fast":
    x_increment = 3
else:
    print("Error setting speed")
    x_increment = 0

alien_0["x_pos"] += x_increment
print(f"Alien 0 is now at X {alien_0["x_pos"]}.")

# It doesn't matter how many points the alien gives us.
del alien_0["points"]
print(alien_0)