# Define a user. Someday we'll define lists of users!
user = {
    "username": "007",
    "last name": "bond",  # Since keys are strings, they can be multiple words
    "first name": "james",
}

# Apparently there's another way to loop besides what I've been doing!
for key, value in user.items():
    print(f"{key.title()}: {value.title()}")